Mechwarrior 3 Sound F/X Extractor          July, 1999

This program is copyright (C)1999, Thomas Turn Jensen

         It may freely be distributed so long
            as all files stays unaltered.

       Questions, Bugs or just general feedback:
                    Mukke@archer.dk

           For the latest version look at:
    http://www.midtfyns-gym.dk/mukke/mw3sfxe.html


How To Use This Program:

When you run the program, it will search for your mw3
installation. It will then initiallize itself, taking
a few seconds. Meanwhile it will show a little about-
box.
After this the box will go away - if the user hasn't
closed it himself - and the program is ready.
To see the sound-clips available click either "Load
lowres sounds" or "Load highres sounds". This will
show the sounds-clips in the main part of the window.

To Extract a file, you first need to set the extract
directory, shown on the lower part. You can click the
small button next to the input-line to browse for a
suitable directory. This way you can also create a
new directory if you wish to do so.

WHen the directory is taken care of, simply double-
click a file in the list and it will quickly extract
it. To extract multiple files at once, you can mark
them and then rightclick. Finally chose Extract and
the program will do so.


Disclaimer:
THE AUTHOR OF THIS PROGRAM TAKES
NO RESPONSIBILITY WHATSOEVER.

----------

Svlad Cjelli of Clan Blood Spirit