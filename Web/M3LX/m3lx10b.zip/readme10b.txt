M3LX patch 1.0b     October 4, 2000
===============

To install: copy the new MTDPXF.DLL file over the old one in your
Mechwarrior3 directory. Make sure you do not have a game or M3LX running
while you do this.

What is changed from M3LX 1.0:
-----------------------------

- A vulnerability recently publicized on the Zone allowed cheaters to
use hacked weapons, stock mechs or maps without being detected. This
patch fixes the problem, even if the cheater is still using M3LX 1.0.
Use of the cheat in question will be diagnosed as: "Game program
discrepancy detected".

- The Warp cheat detection algorithm has been modified to avoid
incorrect activation.

- Some timing parameters have been modified to reduce the lag effects
that could be felt in the game's staging area with a large number of
players.

Notes:
-----

- This is a quick patch to M3LX 1.0. A more complete upgrade (M3LX 1.1)
will soon be released and will fix some more complex problems (in
particular support of Windows 2000).

- The in-game messages announcing the version of M3LX the players are
running will say "M3LX 1.00 active", whether they have this patch or not.
